export type CityListType = {
    _id: string,
    status: boolean,
    deletedAt: number,
    name: string,
    countryId: string,
    stateId: string,
    createdAt: string,
    updatedAt: string,
    __v: number
}