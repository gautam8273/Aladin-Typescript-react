export type SignUpType = {
    firstName: string,
    lastName: string,
    email: string,
    phone: number,
    password: string,
    re_password: string,
    privacyPolicy: string
    type: string
}