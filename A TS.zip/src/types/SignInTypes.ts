export type SignInTypes = {
    email: string,
    password: string,
    privacyPolicy: boolean
}