export type StateListType = {
    _id: string,
    status: boolean,
    deletedAt: number,
    name: string,
    countryId: string,
    createdAt: string,
    updatedAt: string,
    __v: number
}

// export type StateDatType = [{
//     data: StateListType[]
// }]