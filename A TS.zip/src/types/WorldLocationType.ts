export type WorldLocationType = [

]